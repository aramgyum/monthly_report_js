import { cn } from "@/lib/utils";

export function Badge({ className, children }) {
  return (
    <span className={cn(
      "inline-flex items-center rounded-full border px-2 py-0.5 text-xs font-semibold whitespace-nowrap",
      className
    )}>
      {children}
    </span>
  );
}
